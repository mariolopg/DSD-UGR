var http = require("http");
var url = require("url");
var fs = require("fs");
var path = require("path");
var mimeTypes = { "html": "text/html", "jpeg": "image/jpeg", "jpg": "image/jpeg", "png": "image/png", "js": "text/javascript", "css": "text/css", "swf": "application/x-shockwave-flash"};
var SockerIOServer = require("./socketio.js");

class HttpServer {
    constructor(dataBase, port = 8080){
        this.dataBase = dataBase;
        this.port = port;
        this.httpServer = http.createServer( (request, response) => {
            var uri = request.url;
            uri = this.getRuta(uri)
            var fname = uri;
            fs.exists(fname, function(exists) {
                if (exists) {
                    fs.readFile(fname, function(err, data){
                        if (!err) {
                            var extension = path.extname(fname).split(".")[1];
                            var mimeType = mimeTypes[extension];
                            response.writeHead(200, mimeType);
                            response.write(data);
                            response.end();
                        }
                        else {
                            response.writeHead(200, {"Content-Type": "text/plain"});
                            response.write('Error de lectura en el fichero: ' + uri);
                            response.end();
                        }
                    });
                }
                else{
                    console.log("Peticion invalida: " + uri);
                    response.writeHead(302, {"Location": "404"});
                    response.end();
                }
            });
        })

        this.socketio = new SockerIOServer(this.server)
    }

    getRuta(uri){
        var ruta = "";
        var directorio = "public/pages/";
        switch (uri) {
            case "/": case "/home":
                ruta = directorio + "home.html";
                break;

            case "/controlador":
                ruta = directorio + "controlador.html";
                break;

            case "/historico":
                ruta = directorio + "historico.html";
                break;

            case "/404":
                ruta = directorio + "404.html";
                break;
        
            default:
                var peticion = uri.slice(1).split("/");
                if(peticion[0] == 'controlador'){
                    ruta = directorio + "controlador.html";
                    this.dataBase.insertar("eventos", [{time: getTimeStamp(), aire:peticion[1], persiana:peticion[2], temperatura:peticion[3], luminosidad:peticion[4]}])
                    this.socketio.emit("actualizacion aire", peticion[1]);
                }
                else{
                    ruta = path.join(process.cwd(), uri);
                }
                break;
        }

        return ruta;
    }

    iniciar(){
        this.socketio.iniciar();
        this.httpServer.listen(this.port);

        if(this.httpServer.listening)
            console.log("Servidor HTTP iniciado");
        else {
            throw new Error("Error al lanzar el servidor HTTP")
        }
    }
}

function getTimeStamp(){
    var date = new Date();

    var dia = parseDate(date.getUTCDate())
    var mes = parseDate(date.getUTCMonth() + 1)
    var ano = parseDate(date.getFullYear())
    var hora = parseDate(date.getHours())
    var minutos = parseDate(date.getMinutes())
    var segundos = parseDate(date.getSeconds())

    return dia + "/" + mes + "/" + ano + " - " + hora + ":" + minutos + ":" + segundos;
}

function parseDate(date){
    if(date < 10)
        return "0" + date;
    return date;
}

module.exports = HttpServer