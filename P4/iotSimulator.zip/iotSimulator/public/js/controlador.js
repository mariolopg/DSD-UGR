window.onload = function (){
    document.getElementById("actualizar-button").addEventListener("click", actualizar);
    // Sensores
    document.getElementById("slider-temperatura").addEventListener("change", slider("slider-temperatura"));
    document.getElementById("slider-luminosidad").addEventListener("change", slider("slider-luminosidad"));
};

var socket = io();

socket.on("actualizacion aire", function (data) {
    var status = false;
    if(data == "on")
        status = true;
    setStatus("switch-aire", status)
})

function getValue(id){
    var object = document.getElementById(id);
    return object.innerHTML;
}

function actualizar() {
    var serviceURL = document.URL;
    var url = serviceURL + "/" + toggleStatus("switch-aire") + "/" + toggleStatus("switch-persiana") + "/" + getValue("slider-temperatura-value") + "/" + getValue("slider-luminosidad-value");
    var httpRequest = new XMLHttpRequest();
    httpRequest.open("GET", url, true);
    httpRequest.send(null);
}

function slider(id){
    var slider = document.getElementById(id);
    var sliderOutPut = document.getElementById(id + "-value");
    slider.oninput = function() {
        sliderOutPut.innerHTML = this.value;
    }
}

function setStatus(id, status) {
    document.getElementById(id).checked = status;
}

function toggleStatus(id) {
    var checked = document.getElementById(id).checked;
    var status = "off";
    if(checked)
        status = "on";

    return status;
}